<?php
/*
* Template Name: Categories Template
*/
?>
<?php echo 'categories' ?>