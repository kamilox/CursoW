<?php
/*
* Template Name: Single Category
*/
?>

<?php
global $post;
print_r(get_the_category($post->ID)  );
?>
