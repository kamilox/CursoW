<?php $taxonomy = 'procedures'; ?>
<div class="gallery-full-container">
<div style="height: 500px; width: 100%; backgrouns: #f0f0f0;">

<?php
global $post;
    $queried_object = get_queried_object();
    $this_tax = get_taxonomy( $queried_object->taxonomy );

    $terms = get_terms( array(
        'taxonomy' => 'procedures',
        'hide_empty' => false,
    ) );
    
    $terms_ = get_the_terms( $post->ID, 'procedures' );
    foreach ($terms as $key => $value) {
        $termId =  $value->term_id;
        if($termId == $terms_){
            $response == 'ok'; 

        }
    }
    print_r($post);
?>
</div>
    <div class="parent_procedure"><strong><h3> Face Procedures </h3></strong>
        <ul>
            <?php $blepharoplasty = term_exists( 'blepharoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($blepharoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'blepharoplasty', $taxonomy ) ?>" > Blepharoplasty</a></li>
            <?php } ?>

            <?php $facelift = term_exists( 'facelift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($facelift)){?>
                    <li><a href="<?php echo get_term_link( 'facelift', $taxonomy ) ?>" > Facelift</a></li>
            <?php } ?>

            <?php $neck_lift = term_exists( 'neck-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($neck_lift)){?>
                    <li><a href="<?php echo get_term_link( 'neck-lift', $taxonomy ) ?>" > Neck Lift</a></li>
            <?php } ?>

            <?php $rhinoplasty = term_exists( 'rhinoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($rhinoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'rhinoplasty', $taxonomy ) ?>" > Rhinoplasty</a></li>   
            <?php } ?>

            <?php $otoplasty = term_exists( 'otoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($otoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'otoplasty', $taxonomy ) ?>" > Otoplasty</a></li>
            <?php } ?>

            <?php $upper_eyelid_blepharoplasty = term_exists( 'upper-eyelid-blepharoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($upper_eyelid_blepharoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'upper-eyelid-blepharoplasty', $taxonomy ) ?>" > Upper Eyelid Blepharoplasty</a></li>
            <?php } ?>
        </ul>
    </div>

    <div class="parent_procedure"><strong><h3> Breast Procedures</h3></strong>
        <ul style="margin:5px 0 0 15px">
            <?php $breast_asymmetry_correction = term_exists( 'breast-asymmetry-correction', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($breast_asymmetry_correction)){?>
                    <li><a href="<?php echo get_term_link( 'breast-asymmetry-correction', $taxonomy ) ?>" > Breast Asymmetry Correction</a></li>
            <?php } ?>

            <?php $breast_augmentation = term_exists( 'breast-augmentation', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($breast_augmentation)){?>
                    <li><a href="<?php echo get_term_link( 'breast-augmentation', $taxonomy ) ?>" > Breast Augmentation</a></li>       
            <?php } ?>

            <?php $breast_augmentation_with_lift = term_exists( 'breast-augmentation-with-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($breast_augmentation_with_lift)){?>
                    <li><a href="<?php echo get_term_link( 'breast-augmentation-with-lift', $taxonomy ) ?>" > Breast Augmentation with Lift</a></li>
            <?php } ?>

            <?php $breast_lift = term_exists( 'breast-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($breast_lift)){?>
                    <li><a href="<?php echo get_term_link( 'breast-lift', $taxonomy ) ?>" > Breast Lift</a></li>  
            <?php } ?>

            <?php $breast_reduction = term_exists( 'breast-reduction', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($breast_reduction)){?>
                    <li><a href="<?php echo get_term_link( 'breast-reduction', $taxonomy ) ?>"> Breast Reduction</a></li>
                    
            <?php } ?>
        </ul>
    </div>

    <div class="parent_procedure"><strong><h3> Body Procedures </h3></strong>
        <ul style="margin:5px 0 0 15px">
            <?php $body_lift = term_exists( 'body-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($body_lift)){?>
                    <li><a href="<?php echo get_term_link( 'body-lift', $taxonomy ) ?>" > Body Lift</a></li>
            <?php } ?>

            <?php $buttock_augmentation = term_exists( 'buttock-augmentation', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($buttock_augmentation)){?>
                    <li><a href="<?php echo get_term_link( 'buttock-augmentation', $taxonomy ) ?>" > Buttock Augmentation</a></li>
            <?php } ?>
            
            <?php $liposuction = term_exists( 'liposuction', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($liposuction)){?>
                    <li><a href="<?php echo get_term_link( 'liposuction', $taxonomy ) ?>" > Liposuction</a></li>
            <?php } ?>

            <?php $mommy_makeover = term_exists( 'mommy-makeover', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($mommy_makeover)){?>
                    <li><a href="<?php echo get_term_link( 'mommy-makeover', $taxonomy ) ?>" > Mommy Makeover</a></li>
            <?php } ?>
            
            <?php $smartLipo = term_exists( 'smartLipo', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($smartLipo)){?>
                    <li><a href="<?php echo get_term_link( 'smartLipo', $taxonomy ) ?>" > SmartLipo</a></li>
            <?php } ?>

            <?php $tummy_tuck = term_exists( 'tummy-tuck', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($tummy_tuck)){?>
                    <li><a href="<?php echo get_term_link(  'tummy-tuck', $taxonomy ) ?>" > Tummy Tuck</a></li>
            <?php } ?>
        </ul>
    </div>

    <div class="parent_procedure"><strong><h3> Medical Spa Procedures </h3></strong>
        <ul style="margin:5px 0 0 15px">
            <?php $dermabrasion = term_exists( 'dermabrasion', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($dermabrasion)){?>
                    <li><a href="<?php echo get_term_link(  'dermabrasion', $taxonomy ) ?>"> Dermabrasion</a></li>
            <?php } ?>
        </ul>
    </div>
    <div class="parent_procedure"><strong><h3> Laser Treatments </h3></strong>
        <ul style="margin:5px 0 0 15px">
            <?php $phototherapy = term_exists( 'phototherapy', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($phototherapy)){?>
                    <li><a href="<?php echo get_term_link( 'phototherapy', $taxonomy ) ?>" > Phototherapy</a></li>
            <?php } ?>
            
            <?php $vascular_and_redness_treatment = term_exists( 'vascular-and-redness-treatment', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($vascular_and_redness_treatment)){?>
                    <li><a href="<?php echo get_term_link( 'vascular-and-redness-treatment', $taxonomy ) ?>" > Vascular and Redness Treatment</a></li>
            <?php } ?>
            
            <?php $skin_resurfacing = term_exists( 'skin-resurfacing', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($skin_resurfacing)){?>
                    <li><a href="<?php echo get_term_link( 'skin-resurfacing', $taxonomy ) ?>" > Skin Resurfacing</a></li>
            <?php } ?>
            
            <?php $fractional_resurfacing = term_exists( 'fractional-resurfacing', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($fractional_resurfacing)){?>
                    <li><a href="<?php echo get_term_link( 'fractional-resurfacing', $taxonomy ) ?>" > Fractional Resurfacing</a></li>
            <?php } ?>

            <?php $laser_peel = term_exists( 'laser-peel', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($laser_peel)){?>
                    <li><a href="<?php echo get_term_link( 'laser-peel', $taxonomy ) ?>" > Laser Peel</a></li>
            <?php } ?>

            <?php $skin_firming = term_exists( 'skin-firming', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($skin_firming)){?>
                    <li><a href="<?php echo get_term_link( 'skin-firming', $taxonomy ) ?>" > Skin Firming</a></li>
            <?php } ?>
        </ul>
    </div>
    <div class="parent_procedure"><strong><h3> Male Procedures</h3></strong>
        <ul style="margin:5px 0 0 15px">
            <?php $male_breast_reduction = term_exists( 'male-breast-reduction', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_breast_reduction)){?>
                    <li><a href="<?php echo get_term_link( 'male-breast-reduction', $taxonomy ) ?>" > Male Breast Reduction</a></li>
            <?php } ?>
            
            <?php $male_blepharoplasty = term_exists( 'male-blepharoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_blepharoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'male-blepharoplasty', $taxonomy ) ?>" > Male Blepharoplasty</a></li>
            <?php } ?>
            
            <?php $male_liposuction = term_exists( 'male-liposuction', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_liposuction)){?>
                    <li><a href="<?php echo get_term_link( 'male-liposuction', $taxonomy ) ?>" > Male Liposuction</a></li>
            <?php } ?>
            
            <?php $male_neck_lift = term_exists( 'male-neck-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_neck_lift)){?>
                    <li><a href="<?php echo get_term_link( 'male-neck-lift', $taxonomy ) ?>" > Male Neck Lift</a></li>
            <?php } ?>

            <?php $male_otoplasty = term_exists( 'male-otoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_otoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'male-otoplasty', $taxonomy ) ?>" > Male Otoplasty</a></li>
            <?php } ?>

            <?php $male_rhinoplasty = term_exists( 'male-rhinoplasty', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_rhinoplasty)){?>
                    <li><a href="<?php echo get_term_link( 'male-rhinoplasty', $taxonomy ) ?>" > Male Rhinoplasty</a></li>
            <?php } ?>

            <?php $male_thigh_lift = term_exists( 'male-thigh-lift', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($male_thigh_lift)){?>
                    <li><a href="<?php echo get_term_link( 'male-thigh-lift', $taxonomy ) ?>" > Male Thigh Lift</a></li>
            <?php } ?>
                                
            <?php $injectables_for_men = term_exists( 'injectables-for-men', 'procedures' ); // array is returned if taxonomy is given 
                if(isset($injectables_for_men)){?>
                    <li><a href="<?php echo get_term_link( 'injectables-for-men', $taxonomy ) ?>" > Injectables for Men</a></li>
            <?php } ?>			
        </ul>
    </div>
</div>
